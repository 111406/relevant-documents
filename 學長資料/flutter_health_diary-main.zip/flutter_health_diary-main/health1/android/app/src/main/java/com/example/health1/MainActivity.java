package com.example.health1;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
