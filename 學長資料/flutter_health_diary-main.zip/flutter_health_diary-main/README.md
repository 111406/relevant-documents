# Health_Diary
For NTUB representation
The Step Count function still need the activity premission in Apps Premission    --2021/10/27
This app should build in sound null safety situation. Please type "flutter run --no-sound-null-safty" in terminal.  --2021/10/27
Execrise measurement's data is based on this website: https://www.hpa.gov.tw/Pages/Detail.aspx?nodeid=571&pid=9738&fbclid=IwAR1wHoyNvhmRTYvOMsDmu4f3MTf5CorxpL7E6nLOtngROgWPke-GO-bsqE4